//import java.io.DataInputStream;
//import java.io.DataOutputStream;
//
//public class ghesmatepayam {
//   // private  String username;
//    private DataInputStream dis;
//    private DataOutputStream dos;
//
//    ghesmatepayam( DataOutputStream dos , DataInputStream dis){
//      //  this.username=username;
//        this.dis=dis;
//        this.dos=dos;
//    }
//
////    public String getUsername() {
////        return username;
////    }
////
////    public void setUsername(String username) {
////        this.username = username;
////    }
//
//    public String getDis() {
//        return dis;
//    }
//
//    public void setDis(DataInputStream dis) {
//        this.dis = dis;
//    }
//
//    public String getDos() {
//        return dos;
//    }
//
//    public void setDos(DataOutputStream dos) {
//        this.dos = dos;
//    }
//
//
//}
