import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

public class Start implements Initializable {
    public static String username;
    public static String useron;
    @FXML
    Text txt;
    @FXML
    Button btngo;
    @FXML
    Button btnnew;
    @FXML
    TextField txtfusername;
    @FXML
    Button btnstart;
    @FXML
    TextField txtfpass;
String loginshode;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        btnstart.setOnAction(event -> {
            username = txtfusername.getText();
            String pass = txtfpass.getText();
            try {
                /*******************************************************************************/
                /**tabee hamzamani baraye inke 2 nafari ke hmo search kardan ba ham harf bann**/
                hamzamani hamzamani=new hamzamani();
                hamzamani.change3(username);
                /******************************************************************************/
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            try {
                /******************************************************************************/
                /**in ghesmate baraye search vojod username ast**/
                add add = new add();
                ArrayList<String> start = new ArrayList<>();
                start = add.getPerson(username);
                if (start.isEmpty()) {
                    txt.setText("this user name not exsist");
                }
                final String secretKey = "khafe";
                if (!add.getPerson(username).get(5).equals((AES.encrypt(pass,secretKey)))) {
                    txt.setText("your pass is not valid");
                }
                if (add.getPerson(username).get(5).equals(AES.encrypt(pass,secretKey))) {
                    txt.setText("welcome");

                    btngo.setOnAction(event1 -> {
                        try {
                            server.stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("search.fxml"))));
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        /****************************************************************************************************************/
        btnnew.setOnAction(event -> {
            try {
                server.stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("controll.fxml"))));
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}
